"""Row 65 review probes for tutorials/pix2struct_ui_captioning_colab.ipynb (pix2struct-ui-captioning-pipeline @ origin/main).

CPU only (CUDA_VISIBLE_DEVICES=-1). REDUCED SCALE: the adaptation probe uses a randomly initialised
3-decoder-block, 32-wide Pix2Struct built from the repository's committed config, processor and tokenizer (the
same construction as tests/test_adaptation_model.py) on tiny drawn scenes -- never the pinned 282M checkpoint.
It tests the pipeline's state semantics, not caption quality. The BYOD probe replays the notebook's Section 4
BYOD branch verbatim with files.upload() replaced by an in-memory dict; no model is involved.

Usage: python run_probes.py <repo_root> <out_dir>
"""
from __future__ import annotations

import io
import json
import os
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
OUT.mkdir(parents=True, exist_ok=True)
NB = REPO / "tutorials" / "pix2struct_ui_captioning_colab.ipynb"
results: dict = {"repo_root": str(REPO), "env": {"CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES")}}


def save():
    (OUT / "results.json").write_text(json.dumps(results, indent=2, default=str), encoding="utf-8")


# ---------------------------------------------------------------- static probes (source inspection)
nb = json.loads(NB.read_text(encoding="utf-8"))
cells = nb["cells"]
md = ["".join(c["source"]) for c in cells if c["cell_type"] == "markdown"]
code = [(i, "".join(c["source"])) for i, c in enumerate(cells) if c["cell_type"] == "code"]
alltext = "\n".join("".join(c["source"]) for c in cells)
compile_errors = []
for i, src in code:
    try:
        compile(src, f"cell{i}", "exec")
    except SyntaxError as exc:
        compile_errors.append({"cell": i, "error": str(exc)})
blob = subprocess.run(["git", "-C", str(REPO), "rev-parse", "HEAD:tutorials/pix2struct_ui_captioning_colab.ipynb"],
                      capture_output=True, text=True).stdout.strip()
cell = dict(code)
BT = chr(96)
results["static"] = {
    "nbformat": [nb.get("nbformat"), nb.get("nbformat_minor")],
    "cells": len(cells), "code_cells": len(code),
    "compile_errors": compile_errors,
    "notebook_blob": blob,
    "metadata_dimer": nb["metadata"].get("dimer"),
    "outputs_present": sum(bool(c.get("outputs")) for c in cells if c["cell_type"] == "code"),
    "double_brace_in_markdown": [{"cell": i, "snippet": m.group(0)} for i, c in enumerate(cells)
                                 if c["cell_type"] == "markdown"
                                 for m in re.finditer(r"\S*\{\{[^}]*\}\}\S*", "".join(c["source"]))],
    "guided_markers": {k: bool(re.search(p, alltext, re.I)) for k, p in {
        "how_to_use": r"how to use this notebook", "roadmap": r"roadmap", "glossary": r"glossary",
        "troubleshooting": r"troubleshoot", "infrastructure_label": r"infrastructure",
        "predict_prompt": r"\bpredict\b(?!ion)|make a prediction", "check_your_reasoning": r"check your reasoning|<details",
        "what_to_notice": r"what to notice|expected result",
        "conclusion_template": r"conclusion template|your conclusion|write.*conclusion"}.items()},
    "cellView_form_cells": sum(c.get("metadata", {}).get("cellView") == "form" for c in cells),
    "embedded_module_cell_chars": {c["metadata"]["dimer"]["embedded_module"]: len("".join(c["source"]))
                                   for c in cells if c.get("metadata", {}).get("dimer", {}).get("embedded_module")},
    "env_var_DIMER_NOTEBOOK_CI_PREINSTALLED_in_code": "DIMER_NOTEBOOK_CI_PREINSTALLED" in "".join(s for _, s in code),
    "env_var_documented_in_markdown": any("DIMER_NOTEBOOK_CI_PREINSTALLED" in m for m in md),
    "restart_instruction_in_install_cell": "Restart the runtime" in code[0][1],
    "uses_uv": "uv venv" in alltext or "uv pip" in alltext,
    "byod_uses_upload_dialog": "files.upload()" in alltext,
    "byod_location_field": bool(re.search(r"BYOD_(ZIP_)?PATH\s*=.*@param", alltext)),
    "byod_rerun_text": [m.group(0) for m in re.finditer(r"[^.]*re-run from that cell[^.]*\.", alltext)],
    "del_pipe_anywhere": bool(re.search(r"^del pipe\b", alltext, re.M)),
    "pipe_built_only_in_cell": [i for i, s in code if re.search(r"^pipe = ", s, re.M)],
    "pipe_adapt_cell": [i for i, s in code if "pipe.adapt(" in s],
    "runtime_estimate_in_notebook_markdown": bool(re.search(r"\b\d+(\.\d+)?\s*(s|sec|seconds|min|minutes|hours?)\b", "\n".join(md))),
    "optional_experiments_have_code": bool(re.search(r"#\s*(TODO|your turn|exercise|experiment)", "".join(s for _, s in code), re.I)),
    "lr_experiment_claim": [m.group(0) for m in re.finditer(r"raise " + BT + "LEARNING_RATE" + BT + "[^;]*;", alltext)],
    "lr_overfit_claim": [m.group(0) for m in re.finditer(r"a learning rate that is too high[^,]*,[^,]*", alltext)],
    "bare_asserts_outside_modules": [{"cell": i, "line": ln.strip()} for i, s in code
                                     if "embedded_module" not in str(cells[i].get("metadata"))
                                     for ln in s.splitlines() if re.match(r"\s*assert ", ln) and "," not in ln],
    "test_photos_captioned_twice": {
        "section6": "pipe.evaluate(test_records" in cell.get(17, "") and "pipe.predict(test_records" in cell.get(17, ""),
        "section8": "pipe.evaluate(test_records" in cell.get(21, "") and "pipe.predict(test_records" in cell.get(21, ""),
        "section8_also_evaluates_validation": "pipe.evaluate(val_records" in cell.get(21, ""),
    },
    "validation_size_claims": [m.group(0) for m in re.finditer(r"validation split[^.]{0,40}about (sixty|60)[^.]*", alltext)],
    "bleu_explanation": [m.group(0) for m in re.finditer(r"BLEU-4 and ROUGE-L, which can move[^.]*\.", alltext)],
    "spec_version_declared": nb["metadata"].get("dimer", {}).get("notebook_spec"),
}
save()

sys.path.insert(0, str(REPO / "src"))
from PIL import Image, ImageDraw  # noqa: E402

from pix2struct_ui_captioning_pipeline.samples import (  # noqa: E402
    check_split_disjoint, load_byod_dataset, split_dataset, validate_dataset)


# ---------------------------------------------------------------- BYOD branch replay (no model)
def byod_block(uploaded: dict, work: Path):
    """Verbatim logic of the notebook's Section 4 BYOD branch (cell 13), files.upload() replaced by `uploaded`."""
    file_name, payload = next(iter(uploaded.items()))
    byod_dir = work / 'byod'
    byod_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        for member in archive.infolist():
            name = Path(member.filename).name
            if member.is_dir() or not name or name.startswith('.'):
                continue
            (byod_dir / name).write_bytes(archive.read(member))
    records_file = next(p for p in (byod_dir / 'records.jsonl', byod_dir / 'records.json') if p.is_file())
    records = load_byod_dataset(records_file)
    splits = split_dataset(records, seed=42, base_dir=byod_dir)
    dataset_manifests = {name: validate_dataset(part) for name, part in splits.items()}
    splits = {name: manifest['records'] for name, manifest in dataset_manifests.items()}
    return check_split_disjoint(splits)


def png(colour, size=(64, 64)):
    buf = io.BytesIO()
    Image.new("RGB", size, colour).save(buf, format="PNG")
    return buf.getvalue()


def make_zip(entries):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        for n, d in entries:
            z.writestr(n, d)
    return buf.getvalue()


def jsonl(n, folder="", drop=None):
    rows = []
    for i in range(n):
        r = {"id": f"r{i}", "image": f"{folder}img{i}.png", "box": [8, 8, 40, 40],
             "captions": [f"button number {i}", f"tap {i}"], "category": "large-widget"}
        if drop:
            r.pop(drop)
        rows.append(json.dumps(r))
    return "\n".join(rows)


def imgs(n, folder=""):
    return [(f"{folder}img{i}.png", png((i * 7 % 255, 100, 200))) for i in range(n)]


cases = {
    "valid_60_flat": make_zip([("records.jsonl", jsonl(60))] + imgs(60)),
    "valid_60_nested_folder_paths": make_zip([("data/records.jsonl", jsonl(60, folder="images/"))] + imgs(60, "data/images/")),
    "cancelled_upload": None,
    "no_records_file": make_zip(imgs(60)),
    "missing_captions_key": make_zip([("records.jsonl", jsonl(60, drop="captions"))] + imgs(60)),
    "non_image_file": make_zip([("records.jsonl", jsonl(60))] + imgs(59) + [("img59.png", b"not an image")]),
    "small_30_records_within_8_5000_contract": make_zip([("records.jsonl", jsonl(30))] + imgs(30)),
    "small_45_records": make_zip([("records.jsonl", jsonl(45))] + imgs(45)),
}
byod = {}
for name, payload in cases.items():
    with tempfile.TemporaryDirectory() as td:
        uploaded = {} if payload is None else {name + ".zip": payload}
        try:
            byod[name] = {"outcome": "accepted", "split_counts": byod_block(uploaded, Path(td))}
        except BaseException as exc:  # noqa: BLE001
            byod[name] = {"outcome": "error", "type": type(exc).__name__, "message": str(exc)[:240]}
smallest = None
for n in range(8, 200):
    n_test = max(1, round(n * 0.2))
    n_val = round(n * 0.15)
    if min(n_test, n_val, n - n_test - n_val) >= 8:
        smallest = n
        break
byod["_smallest_size_passing_every_split_check_one_record_per_image"] = smallest
results["byod_replay"] = byod
save()

# ---------------------------------------------------------------- stacked-adaptation probe (tiny random model)
import torch  # noqa: E402

torch.set_num_threads(2)
from transformers import Pix2StructConfig, Pix2StructForConditionalGeneration, Pix2StructProcessor  # noqa: E402

from pix2struct_ui_captioning_pipeline import Pix2StructWidgetCaptioningPipeline  # noqa: E402

WD = REPO / "weights" / "pix2struct-widget-captioning-base"


def tiny(seed=0):
    processor = Pix2StructProcessor.from_pretrained(str(WD), local_files_only=True)
    processor.image_processor.max_patches = 64
    config = Pix2StructConfig.from_pretrained(str(WD), local_files_only=True)
    t, v = config.text_config, config.vision_config
    t.hidden_size, t.d_kv, t.num_heads, t.d_ff, t.num_layers = 32, 8, 4, 64, 3
    v.hidden_size, v.d_kv, v.num_attention_heads, v.d_ff, v.num_hidden_layers = 32, 8, 4, 64, 2
    config.text_config, config.vision_config = t, v
    torch.manual_seed(seed)
    model = Pix2StructForConditionalGeneration(config)
    return Pix2StructWidgetCaptioningPipeline._from_model(model, processor, "cpu", "tiny-random")


work = Path(tempfile.mkdtemp())
records = []
for i in range(10):
    im = Image.new("RGB", (128, 96), ["red", "green", "blue", "yellow"][i % 4])
    ImageDraw.Draw(im).text((10, 40), f"SIGN {i}", fill="white")
    p = work / f"s{i}.png"
    im.save(p)
    records.append({"id": f"s{i}", "image": str(p), "box": [5, 30, 120, 70], "group": f"app{i}",
                    "captions": [f"a sign that says sign {i}", f"sign {i}"], "category": "large-widget"})

pipe = tiny()
base = {k: v.detach().clone() for k, v in pipe._model.state_dict().items()}
LR = 1e-3
r1 = pipe.adapt(records, None, epochs=1, lr=LR, batch_size=5, trainable_decoder_layers=2)
after1 = {k: v.detach().clone() for k, v in pipe._model.state_dict().items()}
# Notebook's optional experiment: "set TRAINABLE_DECODER_LAYERS = 1 and compare" -> edit Section 7, rerun it.
r2 = pipe.adapt(records, None, epochs=1, lr=LR, batch_size=5, trainable_decoder_layers=1)
after2 = {k: v.detach().clone() for k, v in pipe._model.state_dict().items()}
first_block = [k for k in base if k.startswith("decoder.layer.1.")]


def changed(a, b, keys):
    return sum(not torch.equal(a[k], b[k]) for k in keys)


art = work / "adapter"
pipe.save_artifact(art)
fresh = tiny()
fresh.load_artifact(art)
fs = fresh._model.state_dict()
mismatch = [k for k in after2 if not torch.equal(after2[k].cpu(), fs[k].cpu())]
control = tiny()
control_equal_base = all(torch.equal(base[k], v) for k, v in control._model.state_dict().items())
manifest = json.loads((art / "manifest.json").read_text())
results["stacked_adaptation"] = {
    "scale": "REDUCED: 3-decoder-block/32-wide random Pix2Struct from the committed config (as tests/test_adaptation_model.py), "
             "10 tiny drawn scenes, no validation split (selection = final epoch so weights move; the notebook passes a "
             "validation split), CPU, max_patches=64, lr=1e-3, 1 epoch each",
    "run1": {"trainable_decoder_layers": 2, "best_epoch": r1["best_epoch"], "n_trainable": r1["n_trainable"]},
    "run2": {"trainable_decoder_layers": 1, "best_epoch": r2["best_epoch"], "n_trainable": r2["n_trainable"],
             "epoch0_note": r2["history"][0].get("note")},
    "run1_changed_tensors_vs_base": changed(base, after1, list(base)),
    "run2_started_from_base": all(torch.equal(base[k], after1[k]) for k in base),
    "first_adapted_block_tensors_changed_vs_base_after_run2": changed(base, after2, first_block),
    "first_adapted_block_tensor_count": len(first_block),
    "artifact_tensors": len(manifest["tensors"]),
    "artifact_layers_recorded": manifest["adapter"]["trainable_decoder_layers"],
    "reloaded_vs_inmemory_mismatched_tensors": len(mismatch),
    "reloaded_vs_inmemory_mismatched_examples": mismatch[:5],
    "rebuild_pipeline_restores_base": control_equal_base,
    "interpretation": "adapt() starts from the pipeline's current weights and labels epoch 0 'frozen model'; a second "
                      "adapt() with fewer blocks leaves first-run changes in the earlier block, which the new artifact "
                      "does not export, so the artifact no longer reproduces the in-memory model. Rebuilding the "
                      "pipeline (re-running Section 3) restores the base. No cell deletes pipe, so a BYOD rerun from "
                      "Section 4 scores the already-adapted pipe as 'frozen' in Section 6 and stacks in Section 7.",
}
save()
print(json.dumps(results, indent=2, default=str)[:9000])
